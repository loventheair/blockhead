<div class="bar">
    <slot name="title"></slot>
    <slot name="controls"></slot>
</div>

<slot></slot>