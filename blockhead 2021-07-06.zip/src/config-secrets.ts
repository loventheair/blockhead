// Cache for .env variables, set in preload() of top level _layout.svelte
export const env: Record<string, string> = {}