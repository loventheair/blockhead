<script lang="ts">
    import { Decimal, Fees, LiquityStore, LQTYStake, StabilityDeposit, TransactionFailedError, Trove, TroveWithPendingRedistribution, UserTrove } from '@liquity/lib-base'
    import { BlockPolledLiquityStore, EthersLiquity, EthersTransactionCancelledError, EthersTransactionFailedError, PopulatableEthersLiquity, PopulatedEthersLiquityTransaction, PopulatedEthersRedemption, ReadableEthersLiquity, SendableEthersLiquity } from '@liquity/lib-ethers'

    LiquityStoreState
</script>