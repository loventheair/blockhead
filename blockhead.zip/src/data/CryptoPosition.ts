export class CryptoPosition {
	currency = 'ETH'
	amount = 0

	comparisonCurrency = 'USD'
	averageRate = 1
}